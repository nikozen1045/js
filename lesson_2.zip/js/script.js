// № 1
// var a = 1, b = 1, c, d;
// c = ++a; alert(c);           // 2 Префиксная форма c = a + 1
// d = b++; alert(d);           // 1 Постфиксная форма d = b; b = b+1;
// c = (2 + ++a); alert(c);      // 5 Префиксная форма с= 2 + (2+1)
// d = (2 + b++); alert(d);      // 4 Постфиксная форма d = 2 + 2; b = b+1;
// alert(a);                    // 3 Было 1 и плюс 2 префикса ++a
// alert(b);                    // 3 Было 1 и плюс 2 постфикса b++
// № 2
// var a = 2;
// var x = 1 + (a *= 2);// x = 1 + ( a = a*2); x= 1 + 4
// alert(x);// x = 5
//№ 3
// var a = +prompt("Введите любое число");
// var b = +prompt("Введите любое число");
// if (a >= 0 && b >= 0) {
//     alert(Math.max(a, b) - Math.min(a, b));
// }
// else if (a <= 0 && b <= 0) {
//     alert(a * b);
// }
// else if (a ^ b) {
//     alert(a + b);
// }
//№ 4
// var q = parseInt(Math.random() * 15);
// switch (q) {
//     case 0:
//         alert("0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15");
//         break;
//     case 1:
//         alert("1 2 3 4 5 6 7 8 9 10 11 12 13 14 15");
//         break;
//     case 2:
//         alert("2 3 4 5 6 7 8 9 10 11 12 13 14 15");
//         break;
//     case 3:
//         alert("3 4 5 6 7 8 9 10 11 12 13 14 15");
//         break;
//     case 4:
//         alert("4 5 6 7 8 9 10 11 12 13 14 15");
//         break;
//     case 5:
//         alert("5 6 7 8 9 10 11 12 13 14 15");
//         break;
//     case 6:
//         alert("6 7 8 9 10 11 12 13 14 15");
//         break;
//     case 7:
//         alert("7 8 9 10 11 12 13 14 15");
//         break;
//     case 8:
//         alert("8 9 10 11 12 13 14 15");
//         break;
//     case 9:
//         alert("9 10 11 12 13 14 15");
//         break;
//     case 10:
//         alert("10 11 12 13 14 15");
//         break;
//     case 11:
//         alert("11 12 13 14 15");
//         break;
//     case 12:
//         alert("12 13 14 15");
//         break;
//     case 13:
//         alert("13 14 15");
//         break;
//     case 14:
//         alert("14 15");
//         break;
//     case 15:
//         alert("15");
//         break;

// }
//№ 5,6
// var a, b;
// function sum(a, b) {
//     return a + b;
// }
// function dif(a, b) {
//     return Math.max(a, b) - Math.min(a, b);
// }
// function mult(a, b) {
//     return a * b;
// }
// function div(a, b) {
//     return Math.max(a, b) / Math.min(a, b);
// }
// a = +prompt("Введите первое число");
// b = +prompt("Введите второе число");
// var operation = prompt("Введите оператор (+ - * /) ");
// function mathOperation(a, b, operation) {
//     switch (operation) {
//         case "+":
//             return (sum(a, b));
//         case "-":
//             return (dif(a, b));
//         case "*":
//             return (mult(a, b));
//         case "/":
//             return (div(a, b));
//     }
// }
// alert(mathOperation(a, b, operation));
//№ 7
//alert(null == 0);//false, потому что на значения undefined и null действует особое правило: они равны друг другу и не равны ничему другому. Но при выражение null >= 0 будет true, так как при нестрогом равенстве и сравнение null рассматривается как 0. 
//№ 8
// function power(val, pow) {
//     if (pow == 1) {
//         return val;
//     }
//     console.log(Math.pow(val, pow));
//     power(pow - 1);
// }
// console.log(power(2, 5));
//Хотел чтобы функция считала 2 в 5 степени, 2 в 4 степени и т.д., к сожалению не получилось
