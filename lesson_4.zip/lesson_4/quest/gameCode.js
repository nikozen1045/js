//После игры необходимо спросить номер вопроса. 
//По номеру вопроса нужно вывести текст вопроса и текст выбранного ответа

var event, ok, ans;

var answers = [];

isCase(works.a00, works.a1, works.a2, works.a0);
answers.push(event);
switch (event) {
    case 1:
        // Первое действие  - если в первом окне ввели 1 то открываем серию окон - окно 2
        isCase(works.b00, works.b1, works.b2, works.b0);
        answers.push(event);
        switch (event) {
            case 1: // Второе действие   Если ввели 2 то также переходим на 4 окно
                isCase(works.d00, works.d1, works.d2, works.d0);
                answers.push(event);
                break;
            case 2:
                isCase(works.d00, works.d1, works.d2, works.d0);
                answers.push(event);
                break;
            case -1: // Второе действие
                break;
            default:
                alert('Ошибка');
        }
        break;
    case 2: // Первое действие    Если в 1 окне ввели 2 то переходим к 3 окну
        isCase(works.c00, works.c1, works.c2, works.c0);
        answers.push(event);
        switch (event) {
            case 1: // Второе действие
                isCase(works.d00, works.d1, works.d2, works.d0);
                answers.push(event);
                break;
            case 2:
                isCase(works.d00, works.d1, works.d2, works.d0);
                answers.push(event);
                break;
            case -1: // Второе действие
                break;
            default:
                alert('Ошибка');
        }
        break;
    case -1: // Первое действие
        break;
    default:
        alert('Ошибка');
}
alert('Спасибо за игру');
ans = +prompt("Хотите вывести ваши ответы в консоль? 1 -да, 2 - нет");
while (1) {
    if (ans == 2) {
        alert("Ну как хотите...");
        break;
    }
    if (ans == 1) {
        console.log(" На первый вопрос: \n" + works.a00 + "\n" + "Вы ответили - " + answ(answers[0], works.a1, works.a2) + '\n' + " На второй вопрос: \n" + otvet(answers[0]) + "\n" + "Вы ответили - " + answ2(answers[0]) + '\n' +
            " На третий вопрос: \n" + works.d00 + "\n" + "Вы ответили - " + answ(answers[2], works.d1, works.d2));
        break;
    }

    else {
        alert('Вы ввели некоректное значение');
        break;
    }
}


//------------------------------------------
function isAnswer(q, event) {
    if (isNaN(event) || !isFinite(event)) {
        alert('Вы ввели недопустимый символ');
        return false;
    }
    else if (event < 1 || event > q) {
        alert('Ваше число выходит из допустимого диапозона');
        return false;
    }
    return true;

}
//x-.00, y-1, z-2, v-0
function isCase(x, y, z, v) {
    do {
        ok = false;
        event = +prompt(x + y + z + '-1 - Выход из игры');
        if (event == -1) {
            break;
        }
        else {
            ok = isAnswer(v, event);
        }
    } while (!ok);
}
function answ(q, w, e) {
    if (q == 1) {
        return w;
    }
    else {
        return e;
    }
}
function otvet(t) {
    if (t == 1) {
        return works.b00;
    }
    else {
        return works.c00;
    }
}
function answ2(i) {
    if (i == 1) {
        return answ(answers[1], works.b1, works.b2);
    }
    else {
        return answ(answers[1], works.c1, works.c2);
    }
}