var otvet, ok, count = 0, sum = 100;
alert('Добро пожаловать в игру: Кто хочет стать милионером');
while (true) {
    ques(vopros.a6, vopros.a00, vopros.a1, vopros.a2, vopros.a3, vopros.a4, vopros.a0);
    ques(vopros.b6, vopros.b00, vopros.b1, vopros.b2, vopros.b3, vopros.b4, vopros.b0);
    ques(vopros.c6, vopros.c00, vopros.c1, vopros.c2, vopros.c3, vopros.c4, vopros.c0);
    ques(vopros.d6, vopros.d00, vopros.d1, vopros.d2, vopros.d3, vopros.d4, vopros.d0);
    break;
}

alert('Спасибо за игру!\nВы выиграли - ' + count);
ans = +prompt("Хотите вывести ваши ответы в консоль? 1 -да, 2 - нет");
while (1) {
    if (ans == 2) {
        alert("Ну как хотите...");
        break;
    }
    if (ans == 1) {
        console.log("На первый вопрос: \n" + vopros.a00 + "\n" + "Правильный ответ: " + answ(vopros.a6) + '\n' + "На второй вопрос: \n" + vopros.b00 + "\n" + "Правильный ответ: " + answ(vopros.b6) + '\n' + "На третий вопрос: \n" + vopros.c00 + "\n" + "Правильный ответ: " + answ(vopros.c6) + '\n' + "На четвертый вопрос: \n" + vopros.d00 + "\n" + "Правильный ответ: " + answ(vopros.d6));
        break;
    }

    else {
        alert('Вы ввели некоректное значение');
        break;
    }
}


//------------------------------------------
function isAnswer(z, otvet) {
    if (isNaN(otvet) || !isFinite(otvet)) {
        alert('Вы ввели недопустимый символ');
        return false;
    }
    else if (otvet < 1 || otvet > z) {
        alert('Ваше число выходит из допустимого диапозона');
        return false;
    }
    else {
        return true;
    }

}

function rigth(d) {
    if (d == 1) {
        return vopros.a5;
    }
    if (d == 2) {
        return vopros.b5;
    }
    if (d == 3) {
        return vopros.c5;
    }
    if (d == 4) {
        return vopros.d5;
    }
}
function nomer(s) {
    alert("Вопрос № " + s + "\n" + "На " + sum + " рублей\n" + "Ваша сумма: " + count);
}
//q-a6, w-a00, e-a1 , r-a2, t-a3,y-a4,u-a0
function ques(q, w, e, r, t, y, u) {
    nomer(q);
    question(w, e, r, t, y, u);
    if (rigth(q) == otvet) {
        alert("Правильно!");
        count += sum;
    }
    else if (otvet == -1) {
        return false;
    }
    else {
        alert("Неправильно!\nПравильный ответ - " + rigth(q) + "\nВаша сумма - " + count);
    }
    sum += 100;
}
//q-a00,w-a1,e-a2,r-a3,r-a4,y-a0
function question(q, w, e, r, t, y) {
    do {
        ok = false;
        otvet = +prompt(q + w + e + r + t + '-1 - Пропуск вопроса');
        if (otvet == -1) {
            break;
        }
        else {
            ok = isAnswer(y, otvet);
        }
    } while (!ok);
}
function answ(q) {
    if (q == 1) {
        return vopros.a3;
    }
    if (q == 2) {
        return vopros.b1;
    }
    if (q == 3) {
        return vopros.c3;
    }
    if (q == 4) {
        return vopros.d4;
    }
}